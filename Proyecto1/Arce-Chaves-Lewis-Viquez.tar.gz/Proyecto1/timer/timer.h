void setUpTimer (void (*pCallback)(int));
void setTimer (int pTime);
